module com.example.javafx_app {
	requires javafx.controls;
	requires javafx.fxml;


	opens com.internshala.javafx_app to javafx.fxml;
	exports com.internshala.javafx_app;
}